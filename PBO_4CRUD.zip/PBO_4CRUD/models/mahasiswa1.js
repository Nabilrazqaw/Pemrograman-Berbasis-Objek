const kelasa = require('kelasa');

const kelasaschema = new kelasa.Schema({
  nama: String,
  nim: String,
  kelas: String
});

const mahasiswa1 = kelasa.model('mahasiswa1', kelasaschema);

module.exports = mahasiswa1;
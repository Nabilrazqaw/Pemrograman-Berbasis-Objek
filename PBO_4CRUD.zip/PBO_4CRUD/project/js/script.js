$(document).ready(function() {
    // Create
    $('#form-mahasiswa').submit(function(e) {
      e.preventDefault();
      const data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: '/mahasiswa',
        data: data,
        success: function(data) {
          console.log(data);
          $('#table-mahasiswa').append(`
            <tr>
              <td>${data.nama}</td>
              <td>${data.nim}</td>
              <td>${data.kelas}</td>
              <td>
                <button class="btn btn-primary" onclick="editBook(${data._id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteBook(${data._id})">Delete</button>
              </td>
            </tr>
          `);
        }
      });
    });
  
    // Read
    $.ajax({
      type: 'GET',
      url: '/books',
      success: function(data) {
        $.each(data, function(index, value) {
          $('#table-mahasiswa').append(`
            <tr>
              <td>${value.nama}</td>
              <td>${value.nim}</td>
              <td>${value.kelas}</td>
              <td>
                <button class="btn btn-primary" onclick="editBook(${value._id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteBook(${value._id})">Delete</button>
              </td>
            </tr>
          `);
        });
      }
    });
  
    // Update
    function editBook(id) {
      $.ajax({
        type: 'GET',
        url: `/mahasiswa/${id}`,
        success: function(data) {
          $('#nama').val(data.nama);
          $('#nim').val(data.nim);
          $('#kelas').val(data.kelas);
          $('#form-mahasiswa').attr('action', `/mahasiswa/${id}?_method=PUT`);
        }
      });
    }
  
    // Delete
    function deleteBook(id) {
      $.ajax({
        type: 'DELETE',
        url: `/books/${id}`,
        success: function(data) {
          $(`tr[data-id="${id}"]`).remove();
        }
      });
    }
  });
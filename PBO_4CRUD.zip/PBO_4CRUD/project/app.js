const express = require('express');
const app = express();
const mahasiswa2Route = require('./routes/mahasiswa2');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

app.use('/mahasiswa2', mahasiswa2Route);

app.listen(3000, () => {
  console.log('Server berjalan di port 3000');
});
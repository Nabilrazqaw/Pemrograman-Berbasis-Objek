const express = require('express');
const router = express.Router();
const Book = require('../mahasiswa1/id');

// Create
router.post('/', (req, res) => {
  const mahasiswa2 = new mahasiswa1(req.body);
  mahasiswa2.save((err, mahasiswa2) => {
    if (err) {
      res.status(400).send(err);
    } else {
      res.send(mahasiswa2);
    }
  });
});

// Read
router.get('/', (req, res) => {
  mahasiswa1.find().then((mahasiswa2) => {
    res.send(mahasiswa2);
  }).catch((err) => {
    res.status(400).send(err);
  });
});

// Update
router.put('/:id', (req, res) => {
  Book.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, mahasiswa2) => {
    if (err) {
      res.status(400).send(err);
    } else {
      res.send(mahasiswa2);
    }
  });
});

// Delete
router.delete('/:id', (req, res) => {
  mahasiswa.findByIdAndRemove(req.params.id, (err, mahasiswa2) => {
    if (err) {
      res.status(400).send(err);
    } else {
      res.send(mahasiswa2);
    }
  });
});

module.exports = router;
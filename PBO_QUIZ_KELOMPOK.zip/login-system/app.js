const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const path = require('path');

// Import routes
const authRoutes = require('./routes/auth');
const agendaRoutes = require('./routes/agenda');

const app = express();

app.set('view engine', 'ejs');

// middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ 
    secret: 'secret',
    resave: false,
    saveUninitialization: true
}));

// set static folder
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to check authentication
app.use((req, res, next) => {
    // Define public routes that don't require authentication
    const publicRoutes = ['/auth/login', '/auth/register', '/'];
    // If accessing landing page
    if (req.path === '/') {
        // If user is logged in, redirect to profile
        if (req.session.user) {
            return res.redirect('/auth/profile');
        }
        // If not logged in, show landing page
        return res.render('landing');
    }
    // If accessing other routes while not logged in (except public routes)
    if (!req.session.user && !publicRoutes.includes(req.path)) {
        return res.redirect('/auth/login');
    }
    next();
});

// Middleware untuk memeriksa autentikasi saat mengedit agenda
const checkAuthForEditAgenda = (req, res, next) => {
    // Memastikan pengguna sudah login
    if (!req.session.user) {
        // Jika tidak login, redirect ke halaman login
        return res.redirect('/auth/login');
    }
    
    // Jika sudah login, lanjutkan ke rute pengeditan agenda
    next();
};
module.exports = checkAuthForEditAgenda;


// Register routes
app.use('/auth', authRoutes);
app.use('/agenda', agendaRoutes);


// Server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
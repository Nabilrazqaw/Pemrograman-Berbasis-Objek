const express = require('express');
const router = express.Router();
const mysql = require('mysql2');

// Create MySQL connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'nodejs_login'
}).promise();

// GET route for displaying agenda
router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM agenda');
        res.render('dashboard', { agenda: rows, user: req.session.user });
    } catch (error) {
        console.error(error);
        res.render('dashboard', { 
            agenda: [], 
            user: req.session.user,
            error: 'Failed to fetch agenda' 
        });
    }
});

// POST route for adding agenda
router.post('/', async (req, res) => {
    const { judul, tanggal, waktu, deskripsi } = req.body;
    try {
        await pool.query(
            'INSERT INTO agenda (judul, tanggal, waktu, deskripsi) VALUES (?, ?, ?, ?)',
            [judul, tanggal, waktu, deskripsi]
        );
        res.redirect('/auth/profile');
    } catch (error) {
        console.error(error);
        res.status(500).send('Error adding agenda');
    }
});

// GET route for editing agenda
router.get('/:id/edit', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM agenda WHERE id = ?', [req.params.id]);
        res.render('edit-agenda', { agenda: rows[0], user: req.session.user });
    } catch (error) {
        console.error(error);
        res.redirect('/auth/profile');
    }
});

// POST route for updating agenda
router.post('/:id/edit', async (req, res) => {
    const { judul, tanggal, waktu, deskripsi } = req.body;
    try {
        await pool.query(
            'UPDATE agenda SET judul = ?, tanggal = ?, waktu = ?, deskripsi = ? WHERE id = ?',
            [judul, tanggal, waktu, deskripsi, req.params.id]
        );
        res.redirect('/auth/profile');
    } catch (error) {
        console.error(error);
        res.redirect('/auth/profile');
    }
});

// GET route for deleting agenda
router.get('/:id/delete', async (req, res) => {
    try {
        await pool.query('DELETE FROM agenda WHERE id = ?', [req.params.id]);
        res.redirect('/auth/profile');
    } catch (error) {
        console.error(error);
        res.redirect('/auth/profile');
    }
});

module.exports = router;  // Make sure to export the router
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const Agenda = require('../models/Agenda');
const loadAgenda = require('../middleware/loadAgenda');

// landing
router.get('/landing', (req, res) => {
    res.render('landing');
});

// render halaman register
router.get('/register', (req, res) => {
    res.render('register');
});

// proses register user
router.post('/register', (req, res) => {
    const { username, password } = req.body;
    
    const hashedPassword = bcrypt.hashSync(password, 10);
    
    const query = "INSERT INTO users (username, password) VALUES (?, ?)";
    // Perbaikan: Menggunakan hashedPassword, bukan password mentah
    db.query(query, [username, hashedPassword], (err, result) => {
        if (err) throw err;
        res.redirect('/auth/login');
    });
});

// render halaman login
router.get('/login', (req, res) => {
    res.render('login');
});

// proses login user
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    const query = "SELECT * FROM users WHERE username = ?";
    db.query(query, [username], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            const user = result[0];
            
            if (bcrypt.compareSync(password, user.password)) {
                req.session.user = user;
                res.redirect('/auth/dashboard');
            } else {
                res.send('Incorrect password');
            }
        } else {
            res.send('User not found');
        }
    });
});

// middleware untuk cek autentikasi
const checkAuth = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// render halaman dashboard
router.get('/dashboard', (req, res) => {
    res.render('dashboard', { user: req.session.user });
});

// Route dashboard dengan data agenda
router.get('/dashboard', checkAuth, async (req, res) => {
    try {
        // Mengambil agenda dari database
        const query = "SELECT * FROM agendas WHERE user_id = ? ORDER BY tanggal ASC, waktu ASC";
        db.query(query, [req.session.user.id], (err, agendas) => {
            if (err) {
                console.error('Error fetching agendas:', err);
                return res.render('dashboard', { 
                    user: req.session.user, 
                    agendas: [] 
                });
            }
            res.render('dashboard', { 
                user: req.session.user, 
                agendas: agendas 
            });
        });
    } catch (error) {
        console.error('Error in dashboard route:', error);
        res.render('dashboard', { 
            user: req.session.user, 
            agendas: [] 
        });
    }
});

// Route untuk menambah agenda
router.post('/agenda/add', checkAuth, (req, res) => {
    const { judul, tanggal, waktu, deskripsi } = req.body;
    const userId = req.session.user.id;

    const query = `
        INSERT INTO agendas (user_id, judul, tanggal, waktu, deskripsi) 
        VALUES (?, ?, ?, ?, ?)
    `;
    
    db.query(query, [userId, judul, tanggal, waktu, deskripsi], (err, result) => {
        if (err) {
            console.error('Error adding agenda:', err);
            return res.status(500).send('Error adding agenda');
        }
        res.redirect('/auth/dashboard');
    });
});

// Route untuk menampilkan form edit agenda
router.get('/agenda/edit/:id', checkAuth, (req, res) => {
    const agendaId = req.params.id;
    const userId = req.session.user.id;

    const query = "SELECT * FROM agendas WHERE id = ? AND user_id = ?";
    db.query(query, [agendaId, userId], (err, results) => {
        if (err) {
            console.error('Error fetching agenda:', err);
            return res.redirect('/auth/dashboard');
        }
        
        if (results.length === 0) {
            return res.redirect('/auth/dashboard');
        }

        res.render('edit-agenda', { agenda: results[0] });
    });
});

// Route untuk memproses edit agenda
router.post('/agenda/edit/:id', checkAuth, (req, res) => {
    const agendaId = req.params.id;
    const userId = req.session.user.id;
    const { judul, tanggal, waktu, deskripsi } = req.body;

    const query = `
        UPDATE agendas 
        SET judul = ?, tanggal = ?, waktu = ?, deskripsi = ?
        WHERE id = ? AND user_id = ?
    `;

    db.query(query, [judul, tanggal, waktu, deskripsi, agendaId, userId], (err, result) => {
        if (err) {
            console.error('Error updating agenda:', err);
            return res.status(500).send('Error updating agenda');
        }
        res.redirect('/auth/dashboard');
    });
});

// Route untuk menghapus agenda
router.get('/agenda/delete/:id', checkAuth, (req, res) => {
    const agendaId = req.params.id;
    const userId = req.session.user.id;

    const query = "DELETE FROM agendas WHERE id = ? AND user_id = ?";
    db.query(query, [agendaId, userId], (err, result) => {
        if (err) {
            console.error('Error deleting agenda:', err);
            return res.status(500).send('Error deleting agenda');
        }
        res.redirect('/auth/dashboard');
    });
});

// render halaman profile
router.get('/profile', (req, res) => {
    res.render('profile', { user: req.session.user });
});

// render halaman edit profile 
router.get('/edit-profile', (req, res) => {
    res.render('edit-profile', { user: req.session.user });
});

// Rute untuk mengupdate profil (misalnya POST)
router.post('/edit-profile', (req, res) => {
    // Logika untuk memperbarui profil pengguna
    // Misalnya, ambil data dari req.body dan simpan ke database
    // Setelah berhasil, redirect ke profil atau dashboard
    res.redirect('/auth/profile');
});

// render halaman update profile
router.get('/update-profile', (req, res) => {
    const userId = req.session.user.id;
    
    // Mengambil data lengkap user dari database
    const query = "SELECT * FROM users WHERE id = ?";
    db.query(query, [userId], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            const userData = result[0];
            res.render('update-profile', { user: userData });
        } else {
            res.redirect('/auth/profile');
        }
    });
});

// proses update profile
router.post('/update-profile', checkAuth, (req, res) => {
    const userId = req.session.user.id;
    const {
        nama,
        tempat_lahir,
        tanggal_lahir,
        jenis_kelamin,
        alamat,
        nomor_telepon,
        agama,
        status_perkawinan,
        pekerjaan,
        kewarganegaraan
    } = req.body;

    const updateQuery = `
        UPDATE users 
        SET 
            nama = ?,
            tempat_lahir = ?,
            tanggal_lahir = ?,
            jenis_kelamin = ?,
            alamat = ?,
            nomor_telepon = ?,
            agama = ?,
            status_perkawinan = ?,
            pekerjaan = ?,
            kewarganegaraan = ?
        WHERE id = ?
    `;

    const values = [
        nama || null,
        tempat_lahir || null,
        tanggal_lahir || null,
        jenis_kelamin || null,
        alamat || null,
        nomor_telepon || null,
        agama || null,
        status_perkawinan || null,
        pekerjaan || null,
        kewarganegaraan || null,
        userId
    ];

    db.query(updateQuery, values, (err, result) => {
        if (err) {
            console.error('Error updating profile:', err);
            res.send('Terjadi kesalahan saat mengupdate profile');
            return;
        }

        // Update session dengan data baru
        req.session.user = {
            ...req.session.user,
            nama,
            tempat_lahir,
            tanggal_lahir,
            jenis_kelamin,
            alamat,
            nomor_telepon,
            agama,
            status_perkawinan,
            pekerjaan,
            kewarganegaraan
        };

        res.redirect('/auth/profile');
    });
});


// proses logout
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/auth/login');
});

router.get('/dashboard', (req, res) => {
    res.render('dashboard', {
        user: req.user,  // assuming you're using passport or similar auth
        agenda: [] // Initialize with empty array as default
    });
});
// Gunakan middleware loadAgenda untuk semua route di bawah ini
router.use(loadAgenda);


// Route untuk menambahkan agenda
router.post('/', async (req, res) => {
  try {
    const agenda = new Agenda(req.body);
    await agenda.save();
    res.redirect('/agenda');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error creating agenda');
  }
});

// Route untuk mengedit agenda
router.get('/:id/edit', async (req, res) => {
  try {
    const agenda = await Agenda.findById(req.params.id);
    res.render('edit-agenda', { agenda });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching agenda');
  }
});

// Route untuk memperbarui agenda
router.put('/:id', async (req, res) => {
  try {
    await Agenda.findByIdAndUpdate(req.params.id, req.body);
    res.redirect('/agenda');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating agenda');
  }
});

// Route untuk menghapus agenda
router.delete('/:id', async (req, res) => {
  try {
    await Agenda.findByIdAndRemove(req.params.id);
    res.redirect('/agenda');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting agenda');
  }
});

// render halaman register
router.get('/edit-agenda', (req, res) => {
    res.render('edit-agenda');
});

module.exports = Agenda;
module.exports = router;
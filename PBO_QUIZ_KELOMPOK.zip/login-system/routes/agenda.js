const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const checkAuthForEditAgenda = require('../middleware/checkAuthForEditAgenda');

// Create MySQL connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'nodejs_login'
}).promise();

// Menampilkan halaman agenda
router.get('/', async (req, res) => {
    try {
        const [agendas] = await pool.query('SELECT * FROM agenda ORDER BY tanggal ASC');
        res.render('agenda', { 
            user: req.session.user,
            agendas: agendas
        });
    } catch (error) {
        console.error(error);
        res.render('agenda', { 
            user: req.session.user,
            agendas: [],
            error: 'Failed to fetch agenda'
        });
    }
});

// Menambah agenda baru
router.post('/add', async (req, res) => {
    const { judul, tanggal, waktu, deskripsi } = req.body;
    try {
        await pool.query(
            'INSERT INTO agenda (judul, tanggal, waktu, deskripsi) VALUES (?, ?, ?, ?)',
            [judul, tanggal, waktu, deskripsi]
        );
        res.redirect('/agenda');
    } catch (error) {
        console.error(error);
        res.redirect('/agenda');
    }
});

// Menampilkan form edit agenda
router.get('/edit/:id', async (req, res) => {
    try {
        const [agenda] = await pool.query('SELECT * FROM agenda WHERE id = ?', [req.params.id]);
        if (agenda.length > 0) {
            res.render('edit-agenda', {
                user: req.session.user,
                agenda: agenda[0]
            });
        } else {
            res.redirect('/agenda');
        }
    } catch (error) {
        console.error(error);
        res.redirect('/agenda');
    }
});

// Update agenda
router.post('/edit/:id', async (req, res) => {
    const { judul, tanggal, waktu, deskripsi } = req.body;
    try {
        await pool.query(
            'UPDATE agenda SET judul = ?, tanggal = ?, waktu = ?, deskripsi = ? WHERE id = ?',
            [judul, tanggal, waktu, deskripsi, req.params.id]
        );
        res.redirect('/agenda');
    } catch (error) {
        console.error(error);
        res.redirect('/agenda');
    }
});

// Hapus agenda
router.get('/delete/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM agenda WHERE id = ?', [req.params.id]);
        res.redirect('/agenda');
    } catch (error) {
        console.error(error);
        res.redirect('/agenda');
    }
});

module.exports = router;
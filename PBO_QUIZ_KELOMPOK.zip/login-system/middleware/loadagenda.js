// middleware/loadAgenda.js
const Agenda = require('../models/Agenda');

const loadAgenda = async (req, res, next) => {
  try {
    const agenda = await Agenda.find();
    req.agenda = agenda; // Simpan agenda ke dalam req
    next(); // Lanjutkan ke route handler berikutnya
  } catch (err) {
    console.error(err);
    res.status(500).send('Error loading agenda');
  }
};

module.exports = loadAgenda;
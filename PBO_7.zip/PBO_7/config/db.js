const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    user:  'root',
    password: '',
    database: 'pertemuan_6shopping'
})

db.connect ((err) => {
    if (err) throw err;
    console.log ('Database connected...');
});

module.exports = db;
